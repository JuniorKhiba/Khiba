from django.http import HttpResponse


def index(request):
    return HttpResponse("Place management index view here")
