from django.db import models
from django.contrib.auth.models import User
from msilib.schema import ListView
# Create your models here.

class Project(models.Model):
    project_name = models.CharField(max_length=200)
    manager = models.ForeignKey(User, on_delete=models.CASCADE)
    contractor = models.CharField(max_length=200)
    start_date = models.DateTimeField()
    end_date = models.DateTimeField()

    def __str__(self) -> str:
        return self.project_name

class Phase(models.Model):
    project = models.ForeignKey(Project, on_delete=models.CASCADE)
    phase_title = models.CharField(max_length=200)
    description = models.CharField(max_length=200)
    start_date = models.DateTimeField()
    end_date = models.DateTimeField()

    def __str__(self) -> str:
        return self.phase_title

    

class Task(models.Model):
    phase = models.ForeignKey(Phase, on_delete=models.CASCADE)
    tasks_title = models.CharField(max_length=200)
    description = models.CharField(max_length=200)
    start_date = models.DateTimeField()
    end_date = models.DateTimeField()

    def __str__(self) -> str:
        return self.tasks_title

#Computer Vision

class LiveView(models.Model):
    project_name = models.CharField(max_length=200)
    manager = models.ForeignKey(User, on_delete=models.CASCADE)
    start_date = models.DateTimeField()
    end_date = models.DateTimeField()



